import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { BodyComponent } from './body.component';
import { Component, OnInit, ElementRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { OptionComponent } from '../option/option.component';

import {
    SocketService,
    MessageService,
    AuthenticationService,
    UserService
} from '../../../../services';
import { Message, IMessage, User } from '../../../../models';
import {
    HttpClientTestingModule,
    HttpTestingController
} from '@angular/common/http/testing';

describe('BodyComponent', () => {
    let fixture: ComponentFixture<BodyComponent>;
    let app: any;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            schemas: [CUSTOM_ELEMENTS_SCHEMA],
            declarations: [BodyComponent],
            imports: [HttpClientTestingModule],
            providers: [
                { provide: SocketService, useClass: SocketService },
                { provide: UserService, useClass: UserService },
                { provide: AuthenticationService, useClass: AuthenticationService },
                { provide: MessageService, useClass: MessageService }
            ]
        }).compileComponents();
        fixture = TestBed.createComponent(BodyComponent);
        app = fixture.debugElement.componentInstance;
    }));
    it('should create the app', async(() => {
        expect(fixture).toBeTruthy();
        expect(app).toBeTruthy();
    }));
    it('should define the varibales on load', () => {
        expect(app.botIsTyping).toBe(false);
    });

    it('should have OnInit', () => {
        expect(app.ngOnInit).toBeDefined();
        app.ngOnInit();
    });

    it('should have scrollToBottom', () => {
        expect(app.scrollToBottom).toBeDefined();
        app.scrollToBottom();
    });

    it('should have selected', () => {
        var option = {
            id: 0
        };
        var option2 = {
            id: 1
        };
        expect(app.selected).toBeDefined();
        app.selected(option);
        app.selected(option2);
    });
});

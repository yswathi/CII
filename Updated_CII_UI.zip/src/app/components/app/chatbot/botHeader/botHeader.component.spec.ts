import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { BotHeaderComponent } from './botHeader.component';
import { Component, Output, EventEmitter, OnInit } from '@angular/core';
describe('BotHeaderComponent ', () => {
  let fixture: ComponentFixture<BotHeaderComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BotHeaderComponent]
    }).compileComponents();
   fixture = TestBed.createComponent(BotHeaderComponent);
   app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have minimizer', async(() => {
    expect(app.setMinimizer).toBeDefined();
    app.setMinimizer();
  }));
  it('should have toggleResize', async(() => {
    expect(app.toggleResize).toBeDefined();
    var flag = true;
    app.toggleResize(flag);
  }));
  it('should have toggleResize', async(() => {
    expect(app.toggleResize).toBeDefined();
    var flag = false;
    app.toggleResize(flag);
  }));
});

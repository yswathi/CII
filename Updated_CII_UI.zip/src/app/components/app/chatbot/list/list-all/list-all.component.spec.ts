import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ListAllComponent } from './list-all.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
describe('ListAllComponent', () => {
  let fixture: ComponentFixture<ListAllComponent>;
  let app: any;
  const mockDialogRef = {
    close: jasmine.createSpy('close')
  };
  const mockMAT_DIALOG_DATA = {
    close: jasmine.createSpy('close')
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [ListAllComponent],
      imports: [MatDialogModule, BrowserAnimationsModule],
      providers: [
        {
          provide: MatDialogRef,
          useValue: mockDialogRef
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: mockMAT_DIALOG_DATA
        }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(ListAllComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have  closeDialog', async(() => {
    expect(app.closeDialog).toBeDefined();
    app.closeDialog();
  }));
  it('should have isSolutionNotAvailable', async(() => {
    expect(app.isSolutionNotAvailable).toBeDefined();
    app.isSolutionNotAvailable();
  }));
});

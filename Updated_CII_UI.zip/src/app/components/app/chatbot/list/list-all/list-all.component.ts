import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
@Component({
  selector: 'app-list-all',
  templateUrl: './list-all.component.html',
  styleUrls: ['./list-all.component.scss'],
})
export class ListAllComponent {
  data: any;
  NoResultContent = "No results found";
  constructor(
    private dialogRef: MatDialogRef<any>,
    @Inject(MAT_DIALOG_DATA) dialogData: any,
  ) {
    this.data = dialogData;
  }
  closeDialog() {
    this.dialogRef.close();
  }
  isSolutionNotAvailable(solution) {
    return !solution || solution === '' || solution === ' ' || solution.length === 0;
  }
}

import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';
import { ListComponent } from './list.component';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  MatDialogModule,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material';
describe('ListComponent', () => {
  let fixture: ComponentFixture<ListComponent>;
  let app: any;
  const mockDialogRef = {
    close: jasmine.createSpy('close')
  };
  const mockMAT_DIALOG_DATA = {
    close: jasmine.createSpy('close')
  };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [ListComponent],
      imports: [MatDialogModule, BrowserAnimationsModule],
      providers: [
        {
          provide: MatDialogRef,
          useValue: mockDialogRef
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: mockMAT_DIALOG_DATA
        }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(ListComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have ngOnInit', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.msgInputs = { text: 'text###hari##priya' };
    app.ngOnInit();
  }));
  it('should have showAll', async(() => {
    expect(app.showAll).toBeDefined();
    app.showAll();
  }));
});

import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material';
import { ListAllComponent } from './list-all/list-all.component';
import { environment } from '../../../../../environments/environment';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
})
export class ListComponent implements OnInit {
  @Input() msgInputs;
  @Input() msgInput;
  dialog: MatDialog;
  constructor(matDialog: MatDialog) {
    this.dialog = matDialog;
  }
  NoResultContent = "No results found";
  msgInputTextCount;
  ngOnInit() {
    if (this.msgInputs) {
      this.msgInputTextCount = this.msgInputs.text === this.NoResultContent;
      this.msgInputs.text = this.msgInputs.text.split(environment.searchItemSeparator);
      this.msgInputs.text.filter((item, index) => {
        if (item) {
          return item;
        } else {
          this.msgInputs.text.splice(index, 1);
        }
      });
      this.msgInputs.text = this.msgInputs.text.map(value => {
        return value.split(environment.searchIncidentSeparator);
      });
    }
  }
  showAll() {
    this.dialog.open(ListAllComponent, {
      hasBackdrop: true,
      disableClose: true,
      data: this.msgInputs,
    });
  }
}

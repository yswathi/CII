import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { MandatoryActionComponent } from './mandatoryAction.component';
import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';
import { Options } from 'selenium-webdriver/opera';

describe(' MandatoryActionComponent', () => {
  let fixture: ComponentFixture<MandatoryActionComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MandatoryActionComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(MandatoryActionComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));

  it('should have onSelect', async(() => {
    expect(app.onSelect).toBeDefined();
    app.onSelect();
  }));
});

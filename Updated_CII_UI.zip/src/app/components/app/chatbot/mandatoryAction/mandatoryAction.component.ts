import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-mandatory-action',
  templateUrl: './mandatoryAction.component.html',
  styleUrls: ['./mandatoryAction.component.scss']
})
export class MandatoryActionComponent {
  @Input() msgInputs;

  @Output() selected = new EventEmitter<boolean>();

  constructor() {}
  onSelect() {
    this.selected.emit(this.msgInputs.options[0]);
  }
}

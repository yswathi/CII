import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { PromptActionComponent } from './promptAction.component';
import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';
describe('PromptActionComponent', () => {
  let fixture: ComponentFixture<PromptActionComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PromptActionComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(PromptActionComponent);
    app = fixture.debugElement.componentInstance;
  }));

  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have onSelect', async(() => {
    expect(app.onSelect).toBeDefined();
    app.onSelect();
  }));
});

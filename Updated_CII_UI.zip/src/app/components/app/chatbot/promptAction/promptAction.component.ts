import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-prompt-action',
  templateUrl: './promptAction.component.html',
  styleUrls: ['./promptAction.component.scss']
})
export class PromptActionComponent {
  @Input() msgInputs;

  @Output() selected = new EventEmitter<boolean>();

  constructor() {}

  onSelect(option) {
    this.selected.emit(option);
  }
}

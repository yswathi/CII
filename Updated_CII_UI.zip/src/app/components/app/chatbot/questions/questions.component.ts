import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.scss']
})
export class QuestionsComponent {
  @Input() msgInputs;

  @Output() selected = new EventEmitter<boolean>();

  constructor() {}

  onSelect(option) {
    this.selected.emit(option);
  }
}

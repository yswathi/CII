import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { TextComponent } from './text.component';
import {
  Component,
  EventEmitter,
  OnInit,
  Output,
  Input,
  ViewEncapsulation
} from '@angular/core';

describe('TextComponent', () => {
  let fixture: ComponentFixture<TextComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TextComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(TextComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have onSelect', async(() => {
    expect(app.onSelect).toBeDefined();
    app.onSelect();
  }));
});

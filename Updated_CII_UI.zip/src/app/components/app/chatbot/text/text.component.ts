import {
  Component,
  EventEmitter,
  Output,
  Input,
  ViewEncapsulation
} from '@angular/core';

@Component({
  selector: 'app-text',
  templateUrl: './text.component.html',
  styleUrls: ['./text.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TextComponent {
  @Input() msgInputs;

  @Output() selected = new EventEmitter<boolean>();

  constructor() {}

  onSelect(option) {
    this.selected.emit(option);
  }
}

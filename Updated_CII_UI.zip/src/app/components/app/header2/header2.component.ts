import { Component } from '@angular/core';

@Component({
  selector: 'app-header2',
  templateUrl: './header2.component.html',
  styleUrls: ['./header2.component.scss']
})
export class Header2Component {
  title = 'header';
  showSubMenu = false;
  technoMenu = false;
  processMenu = false;
  phaseMenu = false;

    constructor() {}
  
    technoMenuClick() : void { 
      this.technoMenu = !this.technoMenu;
      this.processMenu = false;
      this.phaseMenu = false;
  }

}

import { Component, OnInit } from '@angular/core';
import { LoaderService } from './loader.service';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit {
  inProgress: boolean;
  constructor(private loader: LoaderService) {}
  ngOnInit() {
    this.loader.isLoading.subscribe(status => {
      this.inProgress = status;
    });
  }
}


import { Component, OnInit, Inject ,ElementRef, ViewChild,OnChanges, SimpleChanges} from '@angular/core';
import { DialogComponent } from '../../dialog/dialog.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { RequestOptions,Headers } from "@angular/http";
import { adminItem, mask } from '../../../../models/admin';
import { MatDialogRef, MAT_DIALOG_DATA ,MatSnackBar} from '@angular/material';
import { ProxyService } from '../../../../services/proxy.service';
import { environment } from '../../../../../environments/environment';
import { LoaderService } from '../../../app/loader/loader.service';
import * as _ from 'underscore';

@Component({
  selector: 'app-admin-service',
  templateUrl: './admin-service.component.html',
  styleUrls: ['./admin-service.component.scss']
})
export class AdminServiceComponent implements OnInit {
  private snackBar: MatSnackBar;
  editMode: boolean;
  serviceForm: FormGroup;
  apiObject : FormGroup;
  ftpObject : FormGroup;
  donwloadurl : string;
  customerPattern: string;
  customer: string;
  customerGroup: any;
  sampleMapperDownloadUrl: string;
  @ViewChild('fileInput') fileInput: ElementRef;

  types = [{ value: 'FTP', viewValue: 'FTP' }, { value: 'API', viewValue: 'API' }];

  serveiceItem: adminItem = {
    type: '',
    customer : '',
    automationCronValue: '',
    systemName: '',
    url: '',
    userName: '',
    password: '',
    enableFlag: 'Y',
    fieldsMask: [],
    file: '',
    //frequencyType : '',
    //frequencyValue : '',
    email: '',
    id: 0,
    description: '',
  };

  frequency: any = {
    frequencyName : '',frequencyValue : ''
  };
  isDataLoaded: boolean = false;

  // frequencies = [
  //   { value: 'Minutes', viewValue: 'Minutes' },
  //   { value: 'Hourly', viewValue: 'Hourly' },
  //   { value: 'Daily', viewValue: 'Daily' },
  //   { value: 'Weekly', viewValue: 'Weekly' },
  //   { value: 'Monthly', viewValue: 'Monthly' }
  // ];

  // frequencyValuesList: any = {
  //   "Minutes": ["10",'20','30','40','50'],
  //   "Hourly": ["1", '4', '8', '12', '18','20','24'],
  //   "Weekly": ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'],
  //   "Daily": ['1', '4', '8', '12', '16', '20', '24'],
  //   "Monthly": this.getNumbers(12)

  // };

  constructor(private api: ProxyService, private modalService: NgbModal,
    private dialogRef: MatDialogRef<AdminServiceComponent>, @Inject(MAT_DIALOG_DATA) public data: any,
    private loader: LoaderService, snack: MatSnackBar) {
    this.snackBar = snack;
    if (this.data.isEdit) {
      this.serveiceItem = data.serviceData;
      this.serveiceItem.file = data.serviceData.fileName;
      //this.frequency['frequencyName'] = this.serveiceItem['frequencyType'];
      //this.frequency['frequencyValue'] = this.serveiceItem['frequencyValue'];
      this.donwloadurl = `${environment.backendDomain}ims/ticketsystem/${this.serveiceItem.customer}/mapper`;
    }else{
      this.serveiceItem = data.serviceData;
      this.serveiceItem.type = 'FTP';
      this.sampleMapperDownloadUrl = `${environment.backendDomain}ims/file/mapper/sample`;
    }
    this.customer = data.serviceData.customer;

    _.each(this.data.masksList, (m: any) => {
      m.isChecked = false;
      _.each(this.serveiceItem.fieldsMask, (mask) => {
        if (m.fieldName === mask.fieldName && mask.maskEnabled === "Y") {
          m.isChecked = true;
        }
      });
    });

  }
  private getNumbers(count) {
    const numbersList = [];
    for (let i = 0; i < count; i++) {
      numbersList.push(String(i+1));
    }
    return numbersList;
  }

  addUpdateServer() {
    let method = this.data.isEdit? 'update':'post';
    this.serveiceItem.fieldsMask = [];

    _.each(this.data.masksList, (mask: any) => {
      if (mask.isChecked) {
        mask.maskEnabled = "Y";
      } else {
        mask.maskEnabled = "N";
      }
      this.serveiceItem.fieldsMask.push({
        "fieldName": mask.fieldName,
        "systemName": mask.systemName,
        "maskEnabled": mask.maskEnabled,
        "customer": mask.customer,
      })
    })

    //this.serveiceItem['frequencyType'] = this.frequency.frequencyName;
   // this.serveiceItem['frequencyValue'] = this.frequency.frequencyValue;
    this.createCronExpression();
    let form: FormData = new FormData();
   // form.append('fieldmask',this.data.masksList?JSON.stringify(this.data.masksList):null);
    form.append('customer', this.serveiceItem.customer ? this.serveiceItem.customer : null);
    form.append('systemName', this.serveiceItem.systemName ? this.serveiceItem.systemName : null);
    form.append("type", this.serveiceItem.type ? this.serveiceItem.type : null);
    form.append("userName", this.serveiceItem.userName ? this.serveiceItem.userName : null);
    form.append("password", this.serveiceItem.password ? this.serveiceItem.password : null);
    form.append("url", this.serveiceItem.url ? this.serveiceItem.url : null);
    form.append("email", this.serveiceItem.email ? this.serveiceItem.email : null);
    // form.append("enableFlag",this.serveiceItem.enableFlag);
    form.append("automationCronValue", this.serveiceItem.automationCronValue ? this.serveiceItem.automationCronValue : null);
    //form.append("frequencyType", this.serveiceItem.frequencyType ? this.serveiceItem.frequencyType : null);
    //form.append("frequencyValue", this.serveiceItem.frequencyValue ? this.serveiceItem.frequencyValue : null);
    this.serveiceItem.id &&  form.append("id",this.serveiceItem.id);
    form.append("description", this.serveiceItem.description ? this.serveiceItem.description : '');
    if (this.serveiceItem.fileExists) {
      form.append("fileExists", this.serveiceItem.fileExists.toString() ? this.serveiceItem.fileExists.toString(): null);
      form.append('file', this.serveiceItem.file ? this.serveiceItem.file : null);
    }
    let headers : Headers = new Headers();
        headers.append('Content-Type', 'multipart/form-data');
    let options = new RequestOptions({  headers : headers });
    this.loader.start();
    this.api[method](`${environment.backendDomain}ims/ticketsystem/customer`, form , options).subscribe(res => {
    
      if(res.data!=null && res.data.type=="API")
       {
      this.api['post'](`${environment.backendDomain}ims/ticketsystem/fieldMask/`+res.data.id,this.data.masksList).subscribe(res => {
       })
     }

      this.loader.stop();
      this.dialogRef.close(res);
      }, error => {
      this.snackBar.open(error.message, null, {
      duration: 1000
      });
      this.loader.stop();
      });

  }
  createCronExpression() {
    let expression = '';
    if (this.frequency.frequencyName === 'Minutes') {
      expression = `0 0/${this.frequency.frequencyValue} * 1/1 * ? *`;
    }
    else if (this.frequency.frequencyName === 'Hourly') {
      expression = `0 0 0/${this.frequency.frequencyValue} 1/1 * ? *`;
    }
    else if (this.frequency.frequencyName === 'Daily') {
      expression = `0 0 12 1/${this.frequency.frequencyValue} * ? *`;
    }
    else if (this.frequency.frequencyName === 'Weekly') {
      expression = `0 0 12 ? * ${this.frequency.frequencyValue} *`;
    }
    else {
      expression = `0 0 12 1 1/${this.frequency.frequencyValue} ? *`; 
    }
    this.serveiceItem['automationCronValue'] = expression;
  }

  updateExpression() {
    let splitArray = this.serveiceItem['automationCronValue'].split(' ');
    if (splitArray[1] !== '0') {
      this.frequency.frequencyName = 'Minutes';
      let splitList = splitArray[1].split('/');
      this.frequency.frequencyValue = splitList[1];
    }
    else if (splitArray[2] !== '0' && splitArray[2] !== '12') {
      this.frequency.frequencyName = 'Hourly';
      let splitList = splitArray[2].split('/');
      this.frequency.frequencyValue = splitList[1];
    }
    else if (splitArray[3] !== '0' && splitArray[4] === '*') {
      this.frequency.frequencyName = 'Daily';
      let splitList = splitArray[3].split('/');
      this.frequency.frequencyValue = splitList[1];
    }
    else if (splitArray[5] !== '*' && splitArray[5] !== '?') {
      this.frequency.frequencyName = 'Weekly';
      this.frequency.frequencyValue = splitArray[5];
    }
    else {
      this.frequency.frequencyName = 'Monthly';
      let splitList = splitArray[4].split('/');
      this.frequency.frequencyValue = splitList[1];
    }
  }

  closeDialog() {
    this.dialogRef.close({});
     this.serveiceItem ={
      type: '',
      customer : '',
      automationCronValue: '',
      systemName: '',
      url: '',
      userName: '',
      password: '',
      enableFlag: 'Y',
      fieldsMask: [],
      file: '',
      //frequencyType : '',
      //frequencyValue : '',
      email: '',
      id: 0,
      description: '',
    }
  
  }
  
  onFileChange(event) {
    let reader = new FileReader();
    if(event.target.files && event.target.files.length > 0) {
      let file = event.target.files[0];
      this.serveiceItem.file = file;
      this.serveiceItem.fileExists = true;
    }
  }

  typeChange(value: string) {
    if(value === 'FTP'){
      this.serviceForm = this.ftpObject;
      this.serviceForm.patchValue({
        type: this.serveiceItem.type,
        systemName: this.serveiceItem.systemName,
        customer: this.serveiceItem.customer,
        file : this.serveiceItem.file,
        email : this.serveiceItem.email,
        description : this.serveiceItem.description
      })
    }else {
      this.serviceForm = this.apiObject;
      this.serviceForm.patchValue({
        userName: this.serveiceItem.userName,
        password: this.serveiceItem.password,
        type: this.serveiceItem.type,
        systemName: this.serveiceItem.systemName,
       // frequencyName: this.frequency.frequencyName,
      //  frequencyValue: this.frequency.frequencyValue,
        url: this.serveiceItem.url,
        customer: this.serveiceItem.customer,
        file : this.serveiceItem.file,
        email : this.serveiceItem.email,
        description : this.serveiceItem.description,
      });
    } 
  }
  getFormObject(){
    this.apiObject  = new FormGroup({
      userName: new FormControl({ value: '', disabled: this.data.isView || this.isDataLoaded}, Validators.required),
      password: new FormControl({ value: '', disabled: this.data.isView ||  this.isDataLoaded }, Validators.required),
      type: new FormControl({ value: '', disabled: this.data.isView}, Validators.required),
      systemName: new FormControl({ value: '', disabled: this.data.isView }, Validators.required),
      //frequencyName: new FormControl({ value: '', disabled: this.data.isView }, Validators.required),
      //frequencyValue: new FormControl({ value: '', disabled: this.data.isView }, Validators.required),
      url: new FormControl({ value: '', disabled: this.data.isView }, Validators.required),
      customer: new FormControl({ value: '', disabled: this.data.isView }, Validators.required),
      file : new FormControl({value :'', disabled: this.data.isView }, Validators.required),
      email: new FormControl({value :'', disabled: this.data.isView }, Validators.required),
      description : new FormControl({value :'', disabled: this.data.isView })
    });
    this.ftpObject = new FormGroup({
      type: new FormControl({ value: '', disabled: this.data.isView }, Validators.required),
      customer: new FormControl({ value: '', disabled: this.data.isView }, Validators.required),
      systemName: new FormControl({ value: '', disabled: this.data.isView }, Validators.required),
      file : new FormControl({value :'', disabled: this.data.isView }, Validators.required),
      email: new FormControl({value :'', disabled: this.data.isView }, Validators.required),
      description : new FormControl({value :'', disabled: this.data.isView })
    });
    if (this.serveiceItem.type === 'FTP') {
      this.serviceForm = this.ftpObject;
    } else {
      this.serviceForm = this.apiObject;
    }
  }

  ngOnInit() {
    this.getFormObject();
    this.serveiceItem.customer = this.data.customerGroup[0];
    this.isDataLoaded = false;
    if (this.data.isEdit) {
      this.isDataLoaded = this.data.serviceData.dataLoaded;
      this.serveiceItem.customer = this.data.customer;
      this.serviceForm.get('file').clearValidators();
      this.serviceForm.get('file').updateValueAndValidity();
    }
  }
}

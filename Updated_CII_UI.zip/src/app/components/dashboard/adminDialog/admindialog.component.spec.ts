import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';
import { AdminDialogComponent } from './dialog.component';
import { ProxyService } from '../../../services/proxy.service';
import { environment } from '../../../../environments/environment';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import * as _ from 'underscore';
describe('AdminDialogComponent', () => {
  const mockDialogRef = {
    close: jasmine.createSpy('close')
  };
  const mockMAT_DIALOG_DATA = {
    close: jasmine.createSpy('close')
  };
  let fixture: ComponentFixture<AdminDialogComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [AdminDialogComponent],
      imports: [
        ReactiveFormsModule,
        FormsModule,
        HttpClientTestingModule,
        MatDialogModule
      ],
      providers: [
        { provide: ProxyService, useClass: ProxyService },
        { provide: HttpClientTestingModule, useClass: HttpClientTestingModule },
        {
          provide: MatDialogRef,
          useValue: mockDialogRef
        },
        {
          provide: MAT_DIALOG_DATA,
          useValue: mockMAT_DIALOG_DATA
        }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(AdminDialogComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should update frequency', async(() => {
    expect(app.updateFrequency).toBeDefined();
    app.updateFrequency();
  }));
  it('should close dialog', async(() => {
    expect(app.closeDialog).toBeDefined();
    app.closeDialog();
  }));
  it('should  delete', async(() => {
    expect(app.deleteSystem).toBeDefined();
    app.deleteSystem();
  }));
  it('should  call ngOnInit', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));
  it('should  have  createCronExpression()', async(() => {
    expect(app.createCronExpression).toBeDefined();
    app.frequency = {
      frequencyName: 'Minutes'
    };
    app.createCronExpression();
  }));
  it('should  have  createCronExpression()', async(() => {
    expect(app.createCronExpression).toBeDefined();
    app.frequency = {
      frequencyName: 'Hourly'
    };
    app.createCronExpression();
  }));
  it('should  have  createCronExpression()', async(() => {
    expect(app.createCronExpression).toBeDefined();
    app.frequency = {
      frequencyName: 'Daily'
    };
    app.createCronExpression();
  }));
  it('should  have  createCronExpression()', async(() => {
    expect(app.createCronExpression).toBeDefined();
    app.frequency = {
      frequencyName: 'Weekly'
    };
    app.createCronExpression();
  }));
});

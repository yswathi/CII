import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { isArray } from 'util';
import { ListToolTipComponent } from './failures/list-tooltip.component';
import { DialogComponent } from '../dialog/dialog.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { environment } from '../../../../environments/environment';
import { LoaderService } from '../../app/loader/loader.service';
import { AutomationComponent } from './automation.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalStack } from '@ng-bootstrap/ng-bootstrap/modal/modal-stack';

import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
describe('AutomationComponent', () => {
  let fixture: ComponentFixture<AutomationComponent>;
  let app: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      imports: [HttpClientTestingModule, NgbModule.forRoot()],
      declarations: [AutomationComponent],
      providers: [
        {
          provide: LoaderService,
          useClass: LoaderService
        }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(AutomationComponent);
    app = fixture.debugElement.componentInstance;
  }));

  it('should create', () => {
    expect(app).toBeTruthy();
  });
  it('should  call onGridReady', async(() => {
    expect(app.onGridReady).toBeDefined();
    app.onGridReady();
  }));
  it('should  call openDialog', async(() => {
    expect(app.openDialog).toBeDefined();
    var data = {
      colDef: {
        headerName: 'Failure Records'
      }
    };
    app.openDialog(data);
  }));
  it('should  call openDialog', async(() => {
    expect(app.openDialog).toBeDefined();
    var data = {
      colDef: {
        headerName: 'Failure'
      }
    };
    app.openDialog(data);
  }));
});

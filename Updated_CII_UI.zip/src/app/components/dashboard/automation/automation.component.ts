import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { isArray } from 'util';
import { ListToolTipComponent } from './failures/list-tooltip.component';
import { DialogComponent } from '../dialog/dialog.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { environment } from '../../../../environments/environment';
import { LoaderService } from '../../app/loader/loader.service';
import { UserService } from '../../../services/user.service';
import { DatePipe } from '@angular/common';
import { ProxyService } from '../../../services/proxy.service';
import { ActivatedRoute } from '@angular/router';
const httpOptionsTable = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  }),
  withCredentials: true,
  crossDomain: true
};

@Component({
  selector: 'app-automation',
  templateUrl: './automation.component.html',
  styleUrls: ['./automation.component.scss']
})
export class AutomationComponent implements OnInit {
  public frameworkComponents: any;
  customers: any[] = [];
  columnDefs = [
    {
      headerName: 'File Name',
      field: 'fileName',
      enableTooltip: true,
      tooltip: function (params) {
        // This will show valueFormatted if is present, if no just show the value.
        return params.valueFormatted ? params.valueFormatted : params.value;
      }

    },
    {
      headerName: 'Status',
      field: 'automationStatus',
      enableTooltip: true,
      tooltip: function (params) {
        // This will show valueFormatted if is present, if no just show the value.
        return params.valueFormatted ? params.valueFormatted : params.value;
      }
    },
    {
      headerName: 'Start Date & Time',
      field: 'automationStartDate',
      cellRenderer: params => {
        let content = params.value ? this.datePipe.transform(params.value, 'MM-dd-yyyy HH:mm:ss') : 'N/A';
        return `${content}`;
      },
      enableTooltip: true,
      tooltip: function (params) {
        // This will show valueFormatted if is present, if no just show the value.
        return params.valueFormatted ? params.valueFormatted : params.value;
      }
      /*cellRenderer: function(params) {
        let data = this.datePipe.transform(params.value, 'MM-dd-yyyy HH:mm:ss');
        return `${data}`;
        return params.value
          ? new Date(params.value).toLocaleDateString() +
              ' ' +
              new Date(params.value).toLocaleTimeString()
          : '--';
      }*/
    },
    {
      headerName: 'End Date & Time',
      field: 'automationEndDate',
      cellRenderer: params => {
        let content = params.value ? this.datePipe.transform(params.value, 'MM-dd-yyyy HH:mm:ss') : 'N/A';
        return `${content}`;
      },
      enableTooltip: true,
      tooltip: function (params) {
        // This will show valueFormatted if is present, if no just show the value.
        return params.valueFormatted ? params.valueFormatted : params.value;
      }
      /*cellRenderer: function(params) {
        let data = this.datePipe.transform(params.value, 'MM-dd-yyyy HH:mm:ss');
        return `${data}`;
        return params.value
          ? new Date(params.value).toLocaleDateString() +
              ' ' +
              new Date(params.value).toLocaleTimeString()
          : '--';
      }*/
    },
    {
      headerName: 'Comment',
      field: 'comments',
      enableTooltip: true,
      width: 300,
      tooltip: function (params) {
        // This will show valueFormatted if is present, if no just show the value.
        return params.valueFormatted ? params.valueFormatted : params.value;
      }
    },
    {
      headerName: 'Total Records', field: 'totalRecords',
      enableTooltip: true,
      tooltip: function (params) {
        // This will show valueFormatted if is present, if no just show the value.
        return params.valueFormatted ? params.valueFormatted : params.value;
      }
    },
    {
      headerName: 'Success Records', field: 'recordsInserted',
      enableTooltip: true,
      tooltip: function (params) {
        // This will show valueFormatted if is present, if no just show the value.
        return params.valueFormatted ? params.valueFormatted : params.value;
      }
    },
    {
      headerName: 'Failure Records',
      field: 'recordsFailed',
      cellRenderer: 'listTooltip',
      enableTooltip: true,
      tooltip: function (params) {
        // This will show valueFormatted if is present, if no just show the value.
        return params.valueFormatted ? params.valueFormatted : params.value;
      },
    },
    {
      headerName: 'Service Type', field: 'source',
      enableTooltip: true,
      tooltip: function (params) {
        // This will show valueFormatted if is present, if no just show the value.
        return params.valueFormatted ? params.valueFormatted : params.value;
      }
      /* cellRenderer: params => {
         return `FTP`;
       }*/
    },
    {
      headerName: 'Version', field: 'versionNumber',
      enableTooltip: true,
      tooltip: function (params) {
        // This will show valueFormatted if is present, if no just show the value.
        return params.valueFormatted ? params.valueFormatted : params.value;
      },
    }
    /*,
    { headerName: 'Log File', field: 'logFileUrl' }*/
  ];

  rowData: any;
  url: any;
  selectedCustomer: string;

  constructor(private httpClient: HttpClient, private modalService: NgbModal, private router: ActivatedRoute,
    private loader: LoaderService, private datePipe: DatePipe, private userService: UserService, private api: ProxyService) {
    this.frameworkComponents = {
      listTooltip: ListToolTipComponent
    };
    this.userService.getSelectedCustomer().subscribe((data) => {
      this.selectedCustomer = data;
    });
    this.loader.start();
  }

  ngOnInit() {

    this.getCustomers();
  }

  getCustomers() {
    this.api.get(`${environment.backendDomain}ims/ticketsystem/getCustomers`).subscribe(res => {
      if (res.length > 0) {
        this.customers = res;
        if (this.selectedCustomer == null || this.selectedCustomer === undefined) {
          this.selectedCustomer = this.customers[0];
        }
      } else {
        this.customers = [];
      }
    }, error => {
    });
  }
  onGridReady(params?) {
    this.url = environment.backendDomain + 'ims/statistics/customer/' + this.selectedCustomer;
    this.rowData = [];
    this.httpClient.get(this.url).subscribe((res: any) => {
      this.loader.stop();
      if (!isArray(res)) {
        res = [res];
      }

      // res.forEach(value => {
      //   if (value.source === 'API') {
      //     modifiedData.push(value);
      //   } else {
      //     if (value.fileName) {
      //       let fileFound = false;
      //       modifiedData.forEach(md => {
      //         if (md.fileName && md.fileName.indexOf(value.fileName) > -1) {
      //           fileFound = true;
      //           if (value.versionNumber > md.versionNumber) {
      //             md.versionNumber = value.versionNumber;
      //           }
      //         }
      //       });
      //       if (!fileFound) {
      //         modifiedData.push(value);
      //       }
      //     }
      //   }
      // });
      this.rowData = res;
    }, () => {
      this.loader.stop();
    });
  }

  openDialog(data) {
    if (data.colDef.headerName === 'Failure Records') {
      const modalRef = this.modalService.open(DialogComponent, {
        backdrop: 'static',
      });
      modalRef.componentInstance.data = data.data.ticketLogStatistics;
    }
  }

  customerChange(value) {
    this.onGridReady();
    this.selectedCustomer = value;
    this.userService.setSelectedCustomer(this.selectedCustomer);
  }
}

import { Component, OnDestroy } from '@angular/core';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
import { ListToolTipComponent } from './list-tooltip.component';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
describe('ListToolTipComponent', () => {
  let fixture: ComponentFixture<ListToolTipComponent>;
  let app: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      imports: [HttpClientTestingModule],
      declarations: [ListToolTipComponent],
      providers: []
    }).compileComponents();
    fixture = TestBed.createComponent(ListToolTipComponent);
    app = fixture.debugElement.componentInstance;
  }));

  it('should create', () => {
    expect(app).toBeTruthy();
  });
  it('should  call ngOnDestroy', async(() => {
    expect(app.ngOnDestroy).toBeDefined();
    app.ngOnDestroy();
  }));
  it('should  call agInit', async(() => {
    expect(app.agInit).toBeDefined();
    app.agInit();
  }));
  it('should  call refresh', async(() => {
    expect(app.refresh).toBeDefined();
    app.refresh();
  }));
});

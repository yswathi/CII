import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DashboardComponent } from './dashboard.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

describe('  DashboardComponent', () => {
  let fixture: ComponentFixture<DashboardComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      declarations: [DashboardComponent],
      imports: [RouterTestingModule, NgbModule.forRoot()]
    }).compileComponents();
    fixture = TestBed.createComponent(DashboardComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should have ngOnInit()', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));
});

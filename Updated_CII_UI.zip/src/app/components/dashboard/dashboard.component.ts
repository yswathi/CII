import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { environment } from '../../../environments/environment';
import { ProxyService } from '../../services';

@Component({
  selector: 'app-dashboard',
  templateUrl: 'dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  routeLinks: any[];
  activeLinkIndex = -1;
  tabLinks: any[];
  isdisabled:any;
  constructor(private router: Router,  private api: ProxyService) {
    this.routeLinks = [  {
      label: 'About',
      path: './about',
      index: 0,
      mapper: "TAB0",
      disable:true
    },
      {
        // label: 'KNOWLEDGE REPOSITORY',
        label: 'Incident Search',
        path: './knowledge',
        index: 1,
        mapper: "TAB1",
        disable:true
      },
      {
        label: 'Problem Management',
        path: './ppmdash',
        index: 2,
        mapper: "TAB2",
        disable:true
      },
      {
        label: 'Service Insights',
        path: './value',
        index: 3,
        mapper: "TAB3",
        disable:true
      },
      {
        label: 'Incident Forecast',
        path: './amsi',
        index: 4,
        mapper: "TAB4",
        disable:true
      },
      {
        label: 'Admin',
        path: '/admindashboard/admin',
        index: 5,
        mapper: "TAB5",
        disable:true
      }, 
    
      /*{
        label: 'ADMIN SCHEDULER',
        path: './admin',
        index: 3
      },
      /*{
        label: 'FILE LOAD STATUS',
        path: './automation',
        index: 5
      },
      {
        label: 'OVERALL RUN STATS',
        path: './statistics',
        index: 6
      }*/
    ];
  }
  ngOnInit(): void {
    this.api.get(environment.backendDomain + 'ims/user').subscribe((response) => {
      const name = response.firstName;
      const resources = response.resources ? response.resources : [];
      if (resources) {
        this.routeLinks.filter((link) => {
          if( resources.indexOf(link.mapper) == -1){
            link.disable=true;
          }else{
            link.disable=false;
          }
        });
        // this.tabLinks.unshift(aboutTab);
      }

      
    });

    const aboutTab =  {
      label: 'ABOUT',
      path: './about',
      index: 0,
      mapper: "TAB0"
    };

    this.router.events.subscribe(res => {
      this.activeLinkIndex = this.routeLinks.find(tab => tab.link === '.' + this.router.url
      );
    });
  }

}

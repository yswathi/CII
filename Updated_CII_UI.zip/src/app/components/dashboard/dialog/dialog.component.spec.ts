import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { DialogComponent } from './dialog.component';
import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';

describe(' DialogComponent', () => {
  let fixture: ComponentFixture<DialogComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [DialogComponent],
      imports: [HttpClientTestingModule],
      providers: [{ provide: NgbActiveModal, useClass: NgbActiveModal }]
    }).compileComponents();
    fixture = TestBed.createComponent(DialogComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
});

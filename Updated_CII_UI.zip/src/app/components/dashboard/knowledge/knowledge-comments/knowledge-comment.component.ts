import { Component, OnInit, Inject ,ElementRef, ViewChild,OnChanges, SimpleChanges} from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA,MatSnackBar } from '@angular/material';
import { ProxyService } from '../../../../services/proxy.service';
import { environment } from '../../../../../environments/environment';
import * as _ from 'underscore';
@Component({
  selector: 'knowledge-service-rating',
  templateUrl: './knowledge-comment.component.html',
  styleUrls: ['./knowledge-comment.component.scss'],
})
export class KnowledgeCommentsComponent implements OnInit {
  updatedComment: string;
  knowledgeCommentsForm: FormGroup;
  CommentsData: Array<any>;
  totalData: any;
  isFormVisible: boolean = false;
  snackBar: MatSnackBar;
  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private api : ProxyService,
    private dialogRef: MatDialogRef<KnowledgeCommentsComponent>,
    private snack: MatSnackBar) {
    this.totalData = this.data.serviceData;
    this.CommentsData = this.data.serviceData.comments;
    this.snackBar = snack;
  }
  addComments() {
    this.isFormVisible = true;
  }
  // GET /ims/{customer}/{incidentId}/kr/comment?comment=testing
  addUpdateServer() {
    const customer = this.data.serviceData.customer;
    this.api
          .get(`${environment.backendDomain}ims/externalService/${customer}/${this.totalData.id}/kr/comment?comment=${encodeURIComponent(this.updatedComment)}`)
          .subscribe((res) => {
            if (res === "SUCCESS") {
              res = `Comment(s) updated successfully`;
            }
            this.snackBar.open(res, null, {
              duration: 3000,
            });
            this.dialogRef.close(true);
          });
  }
  ngOnInit() {
    this.knowledgeCommentsForm = new FormGroup({
      comments: new FormControl({ value: '' }, Validators.required)
    });
  }

}

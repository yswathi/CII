import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { environment } from '../../../../environments/environment';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { KnowledgeComponent } from './knowledge.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ProxyService } from '../../../services/proxy.service';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';

describe('KnowledgeComponent', () => {
  let fixture: ComponentFixture<KnowledgeComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [KnowledgeComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      imports: [HttpClientTestingModule, FormsModule, MatSnackBarModule],
      providers: [
        { provide: NgbActiveModal, useClass: NgbActiveModal },
        { provide: ProxyService, useClass: ProxyService }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(KnowledgeComponent);
    app = fixture.debugElement.componentInstance;
  }));

  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  it('should  call ngOnInit', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));
  it('should  call setStep', async(() => {
    expect(app.setStep).toBeDefined();
    app.setStep();
  }));
  it('should  call nextStep', async(() => {
    expect(app.nextStep).toBeDefined();
    app.nextStep();
  }));
  it('should  call prevStep', async(() => {
    expect(app.prevStep).toBeDefined();
    app.prevStep();
  }));
  it('should  call  goSearch', async(() => {
    expect(app.goSearch).toBeDefined();
    app.goSearch();
  }));
  it('should  call getKnowledgeResults', async(() => {
    expect(app.getKnowledgeResults).toBeDefined();
    app.getKnowledgeResults();
  }));
  it('should  call getElasticResults', async(() => {
    expect(app.getElasticResults).toBeDefined();
    app.getElasticResults();
  }));
  it('should  call clearOldData', async(() => {
    expect(app.clearOldData).toBeDefined();
    app.clearOldData();
  }));
  it('should  call getKRResults', async(() => {
    expect(app.getKRResults).toBeDefined();
    app.getKRResults();
  }));
});

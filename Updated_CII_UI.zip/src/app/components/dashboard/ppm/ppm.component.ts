import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ProxyService } from '../../../services/proxy.service';
import { environment } from '../../../../environments/environment';
import * as _ from 'underscore';
import { DatePipe } from '@angular/common';
import { LoaderService } from '../../app/loader/loader.service';
import { Router } from '@angular/router';

@Component({
  templateUrl: './ppm.component.html',
  styleUrls: ['./ppm.component.scss']
})
export class PpmComponent implements OnInit {
  rowData: any;
  columnDefs = [
    {
      headerName: 'Incident ID',
      field: 'id',
      width: 150,
      cellRenderer: params => {
        return `<a href="javascript:void(0)" class='a_grid'>${
          params.value
        }</a>`;
      }
    },
    {
      headerName: 'Title',
      field: 'title',
      width: 350,
      cellRenderer: params => {
        return `${params.data.ppmData.input_incident.col10}`;
      },
      enableTooltip: true,
      tooltip: function(params) {
        return params.data.ppmData.input_incident.col10;
      }
    },
    {
      headerName: 'Assignment Group',
      field: 'group',
      width: 300,
      cellRenderer: params => {
        return `${params.data.ppmData.input_incident.col17}`;
      },
      enableTooltip: true,
      tooltip: function(params) {
        return params.data.ppmData.input_incident.col17;
      }
    },
    {
      headerName: 'Open Time',
      field: 'time',
      autoHeight: true,
      cellRenderer: params => {
        let date1 = this.datePipe.transform(
          params.data.ppmData.input_incident.col11,
          'short'
        );
        return `${date1}`;
      }
    }
  ];

  constructor(
    private api: ProxyService,
    private datePipe: DatePipe,
    private loader: LoaderService,
    private router: Router
  ) {}

  ngOnInit() {
    this.loader.start();
    this.rowData = [];
    this.api
      .get(`${environment.knowledgeRepositoryDomain}ppm/get_all`)
      .subscribe(
        res => {
          let todayList = [];
          let yesterdayList = [];
          let olderList = [];
          let yestDay = new Date();
          yestDay = new Date(yestDay.setDate(yestDay.getDate() - 1));

          _.each(res.response, (notification: any) => {
            if (
              new Date(notification.ppmData.input_incident.col11) === new Date()
            ) {
              todayList.push(notification);
            } else if (
              new Date(notification.ppmData.input_incident.col11) === yestDay
            ) {
              yesterdayList.push(notification);
            } else {
              olderList.push(notification);
            }
          });
          console.log(todayList, olderList, yesterdayList);
          this.rowData.push(
            {
              type: 'Today',
              list: todayList
            },
            {
              type: 'Yesterday',
              list: yesterdayList
            },
            {
              type: 'Older',
              list: olderList
            }
          );
          this.loader.stop();
        },
        err => {
          this.loader.stop();
        }
      );
  }

  setStep() {}

  cellTriggered(event) {
    if (event.colDef.headerName === 'Incident ID') {
      this.router.navigateByUrl(`/dashboard/ppmDetails/${event.data.id}`);
    }
  }
}

import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ProxyService } from '../../../../services/proxy.service';
import { environment } from '../../../../../environments/environment';
import * as _ from 'underscore';
import { DatePipe } from '@angular/common';
import { LoaderService } from '../../../app/loader/loader.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  templateUrl: './ppmDetails.component.html',
  styleUrls: ['./ppmDetails.component.scss']
})
export class PpmDetailsComponent implements OnInit {
  rowData: any = {
    ppmData: {
      input_incident: {},
      priority_notification: false,
      problem_notification: false
    }
  };
  sub: any;
  id: any;
  columnDefs = [
    {
      headerName: 'Incident ID',
      field: 'id',
      width: 150,
      cellRenderer: params => {
        return `${params.data.col3}`;
      }
    },
    {
      headerName: 'Title',
      field: 'title',
      width: 350,
      cellRenderer: params => {
        return `${params.data.col10}`;
      },
      enableTooltip: true,
      tooltip: function(params) {
        return params.data.col10;
      }
    },
    {
      headerName: 'Assignment Group',
      field: 'group',
      width: 200,
      cellRenderer: params => {
        return `${params.data.col17}`;
      },
      enableTooltip: true,
      tooltip: function(params) {
        return params.data.col17;
      }
    },
    {
      headerName: 'Open Time',
      field: 'time',
      autoHeight: true,
      cellRenderer: params => {
        let date1 = this.datePipe.transform(params.data.col11, 'short');
        return `${date1}`;
      }
    },
    
  ];

  columnDefs1 = this.columnDefs.concat([
    {
      headerName: 'Solution',
      field: 'solution',
      autoHeight: true,
      width: 400,
      cellRenderer: params => {
        return `${params.data.col25}`;
      },
      enableTooltip: true,
      tooltip: function(params) {
        return params.data.col25;
      }
    }
  ]);

  constructor(
    private api: ProxyService,
    private datePipe: DatePipe,
    private loader: LoaderService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
      this.id = params.id;
      this.getDetails(params.id);
    });
  }

  getDetails(id) {
    this.loader.start();
    this.api
      .get(`${environment.knowledgeRepositoryDomain}ppm/get_all`)
      .subscribe(
        res => {
          _.each(res.response, (notification: any) => {
            if (notification.id === id) {
              this.rowData = notification;
            }
          });
          this.loader.stop();
        },
        err => {
          this.loader.stop();
        }
      );
  }

  setStep() {}

  goBack() {
    this.router.navigateByUrl('/dashboard/notifications');
  }
  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}

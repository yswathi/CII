import { element } from 'protractor';
import { Component, OnInit, Inject, ElementRef, ViewChild, OnChanges, SimpleChanges, HostListener } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA, MatSnackBar } from '@angular/material';
import { ProxyService } from '../../../../../services/proxy.service';
import { environment } from '../../../../../../environments/environment';
import * as _ from 'underscore';
@Component({
    selector: 'edit',
    templateUrl: './edit.component.html',
    styleUrls: ['./edit.component.scss']
})

export class EditComponent implements OnInit {
    displayData: string = "";
    serviceData: any = [];
    public description;
    public Isvalid;
    public oldData;
    public selectedIndex = -1;
    public displayList: any = [];
    public options: any = ['one', 'two', 'three', 'owl', 'ten', 'aaa', 'abc', 'aab'];
    public Isedit: boolean = false;
    public showDropDown: boolean = false;
    public searchValue;
    public itsmid: boolean = false;;
    snackBar: MatSnackBar;
    constructor( @Inject(MAT_DIALOG_DATA) public data: any,
        private api: ProxyService,
        private dialogRef: MatDialogRef<EditComponent>,
        private snack: MatSnackBar) {
        this.displayData = this.data.serviceData.solution;
        this.description = this.data.serviceData.problem_description;
        this.serviceData = this.data.serviceData;
        this.displayData = this.serviceData.solution;
        this.Isvalid = this.serviceData.valid;
        this.searchValue = this.serviceData.itsm_problem_id;
        this.snackBar = snack;
        this.oldData = this.serviceData;
    }
    edit() {
        this.Isedit = true;
        if(this.searchValue != ''){
        this.itsmid = true;
        }
    }
    ngOnInit() {
        this.displayData = this.data.serviceData.solution
        this.getitsmlist();
    }
    
    changeSearchValue(data) {
        console.log(data)
        // this.getitsmlist()
        if (data && this.options != "No problems") {
            this.selectedIndex = -1;
            this.displayList = this.options.filter(ele => ele.startsWith(data.toUpperCase()));
            this.showDropDown = true;
        } else {
            this.displayList = this.options;
            this.selectedIndex = -1;
            this.showDropDown = false;
        }
     
    }

    restrictValue(data) {
        this.showDropDown = false;
        if (!this.options.includes(data)) {
            this.searchValue = '';
        }
        if (data) {
            this.displayList = this.options.filter(ele => ele.startsWith(data));
        } else {
            this.displayList = this.options;
        }
    }

    showList() {
        // this.showDropDown = true;
        // this.selectedIndex = 0;
        // this.searchValue = this.displayList[this.selectedIndex];
    }

    moveListup(ev) {
        ev.preventDefault();
        if (this.showDropDown) {
            setTimeout(() => {
                var list = document.getElementById('item-list');
                const minLen = list.scrollHeight / this.displayList.length;
                if (this.selectedIndex > 0) {
                    this.selectedIndex--;
                    this.searchValue = this.displayList[this.selectedIndex];
                    list.scrollTo(0, (this.selectedIndex) * minLen);
                }
            }, 10);
        }

    }

    moveListdown(ev) {
        ev.preventDefault();
        if (this.showDropDown) {
            setTimeout(() => {
                var list = document.getElementById('item-list');
                const minLen = list.scrollHeight / this.displayList.length;
                if (this.selectedIndex < this.displayList.length - 1) {
                    this.selectedIndex++;
                    this.searchValue = this.displayList[this.selectedIndex];
                    list.scrollTo(0, (this.selectedIndex) * minLen);
                }
            }, 10);
        }
    }

    Updatedata() {
        if(this.oldData.valid !=this.Isvalid || this.oldData.problem_description != this.description ||this.oldData.itsm_problem_id != this.searchValue){
                  
            if(this.options.indexOf(this.searchValue)!=-1 ||this.searchValue=='' ) {
                this.uploadData();
            }else if(this.oldData.itsm_problem_id=='' && this.searchValue==''){
                this.uploadData();
            }else{
                const msg = 'Please enter ITSM problem ID from suggestions';
                this.snackBar.open(msg, null, {
                    duration: 3000,
                });
            }
        }else{
            const msg = 'No Update Found';
            this.snackBar.open(msg, null, {
                duration: 3000,
            });
            this.dialogRef.close(true);
        }
       
    }


    selectItem(index) {
        this.selectedIndex = index;
    }

    bindSelection(index, ev) {
        ev.stopPropagation();
        this.searchValue = this.displayList[index];
        this.showDropDown = false;
    }

    getitsmlist(){
        this.api
        .get(`${environment.backendDomain}ims/dashboard/ppm/${this.serviceData.customer}/problem/ids`)
        .subscribe((res) => {
            console.log(res)
            this.options = res.problem_ids;
        })
    }

    @HostListener('click') removeDropdown() {
        this.showDropDown = false;
        if (!this.options.includes(this.searchValue)) {
            this.searchValue = '';
        }
    }
    uploadData(){
        let payload = {
            "customer": this.serviceData.customer,
            "created_at": this.serviceData.created_at,
            "last_modified_date": this.serviceData.last_modified_date,
            "resolution_time": this.serviceData.resolution_time,
            "valid": this.Isvalid,
            "incidents": this.serviceData.incidents,
            "problem_description": this.description,
            "total_incidents": this.serviceData.total_incidents,
            "problem": this.serviceData.problem,
            "problem_id": this.serviceData.problem_id,
            "itsm_problem_id":this.searchValue
        }
        this.api
        return this.api.post(
            `${environment.backendDomain}ims/dashboard/ppm/incidents`,
            payload
        ).subscribe(
            (res) => {
                if (res === "SUCCESS") {
                    res = `Problem Detail(s) updated successfully`;
                }
                this.snackBar.open(res, null, {
                    duration: 3000,
                });
                this.dialogRef.close(true);
            });
    }

    validate(event) {
        const charCode = event.keyCode;
        console.log(charCode);
        if (((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode > 47 && charCode < 58) || charCode == 8)) {
            this.searchValue = event.target.value;
        } else {
            this.searchValue = '';
        }
    }
}

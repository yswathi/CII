import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ProxyService } from '../../../services/proxy.service';
import { environment } from '../../../../environments/environment';
import * as _ from 'underscore';
import { DatePipe } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { MatDatepickerModule, MatNativeDateModule } from '@angular/material';
import { StatisticsComponent } from './statistics.component';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
describe('StatisticsComponent', () => {
  let fixture: ComponentFixture<StatisticsComponent>;
  let app: any;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [StatisticsComponent],
      imports: [
        HttpClientTestingModule,
        MatDatepickerModule,
        MatNativeDateModule,
        FormsModule,
        ReactiveFormsModule
      ],
      providers: [
        { provide: ProxyService, useClass: ProxyService },
        { provide: DatePipe, useClass: DatePipe }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(StatisticsComponent);
    app = fixture.debugElement.componentInstance;
  }));

  it('should create', () => {
    expect(app).toBeTruthy();
  });
  it('should  have ngOnInit()', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));
  it('should  have clear()', async(() => {
    expect(app.clear).toBeDefined();
    app.clear();
  }));
  it('should  have  getSysyemList()', async(() => {
    expect(app.getSysyemList).toBeDefined();
    app.getSysyemList();
  }));
  it('should  have getStatisticsList()', async(() => {
    expect(app.getStatisticsList).toBeDefined();
    app.getStatisticsList();
  }));
  it('should  have filterData()', async(() => {
    expect(app.filterData).toBeDefined();
    app.automationStartDate = true;

    app.filterData();
  }));
  it('should  have  updateSysyemNames()', async(() => {
    expect(app.updateSysyemNames).toBeDefined();
    app.updateSysyemNames();
  }));
  it('should  have  onItemSelect()', async(() => {
    expect(app.onItemSelect).toBeDefined();
    app.onItemSelect();
  }));
  it('should  have   OnItemDeSelect()', async(() => {
    expect(app.OnItemDeSelect).toBeDefined();
    app.OnItemDeSelect();
  }));
  it('should  have  onSelectAll()', async(() => {
    expect(app.onSelectAll).toBeDefined();
    app.onSelectAll();
  }));
  it('should  have onDeSelectAll()', async(() => {
    expect(app.onDeSelectAll).toBeDefined();
    app.onDeSelectAll();
  }));
});

import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ProxyService } from '../../../services/proxy.service';
import { environment } from '../../../../environments/environment';
import { UserService } from '../../../services/user.service';
import * as _ from 'underscore';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-statistics',
  templateUrl: './statistics.component.html',
  styleUrls: ['./statistics.component.scss']
})
export class StatisticsComponent implements OnInit {
  systemList = [];
  customers: any[] = [];
  query = {
    systemNames: [],
    source: null,
    automationStartDate: null,
    automationEndDate: null,
  };
  statisticsList = [];
  today = new Date();
  dropdownSettings: any = {};
  selectedCustomer: string;
  columnDefs = [
    {
      headerName: 'Date',
      field: 'automationStartDate',
      enableTooltip: true,
      tooltip: function (params) {
        return params.valueFormatted ? params.valueFormatted : params.value;
      },
      cellRenderer: params => {
        let data = this.datePipe.transform(params.value, 'MM-dd-yyyy HH:mm:ss');
        return `${data}`;
      },
    },
    {
      headerName: 'File Name', field: 'fileName', enableTooltip: true,
      tooltip: function (params) {
        return params.valueFormatted ? params.valueFormatted : params.value;
      },
    },
    {
      headerName: 'Data Load Status', field: 'automationStatus',
      enableTooltip: true,
      tooltip: function (params) {
        return params.valueFormatted ? params.valueFormatted : params.value;
      },
      cellRenderer: params => {
        let content = params.value ? params.value : 'N/A';
        return `${content}`;
      }
    },
    {
      headerName: 'Forecast Status',
      field: 'forecastStatus',
      enableTooltip: true,
      tooltip: function (params) {
        return params.valueFormatted ? params.valueFormatted : params.value;
      },
      cellRenderer: params => {
        let content = params.value ? params.value : 'N/A';
        return `${content}`;
      }
    },
    {
      headerName: 'Knowledge Status',
      field: 'knowledgeBaseStatus',
      enableTooltip: true,
      tooltip: function (params) {
        return params.valueFormatted ? params.valueFormatted : params.value;
      },
      cellRenderer: params => {
        let content = params.value ? params.value : 'N/A';
        return `${content}`;
      }
    },
    {
      headerName: 'PPM Status',
      field: 'ppmStatus',
      enableTooltip: true,
      tooltip: function (params) {
        return params.valueFormatted ? params.valueFormatted : params.value;
      },
      cellRenderer: params => {
        let content = params.value ? params.value : 'N/A';
        return `${content}`;
      }
    },
    {
      headerName: 'Dashboard Refresh', field: 'tableauStatus',
      enableTooltip: true,
      tooltip: function (params) {
        return params.valueFormatted ? params.valueFormatted : params.value;
      },
      cellRenderer: params => {
        let content = params.value ? params.value : 'N/A';
        return `${content}`;
      }
    },
    {
      headerName: 'Service Type', field: 'source',
      enableTooltip: true,
      tooltip: function (params) {
        return params.valueFormatted ? params.valueFormatted : params.value;
      },
      cellRenderer: params => {
        return `FTP`;
      }
    },
    {
      headerName: 'Service Name', field: 'systemName', enableTooltip: true,
      tooltip: function (params) {
        return params.valueFormatted ? params.valueFormatted : params.value;
      },
    },
  ];

  constructor(private api: ProxyService, private datePipe: DatePipe, private userService: UserService) {
    this.userService.getSelectedCustomer().subscribe((data) => {
      this.selectedCustomer = data;
    });
  }

  ngOnInit() {
    this.getCustomers();
    this.getSysyemList();
    // this.query['customer'] = this.selectedCustomer;
    // this.getStatisticsList(this.query);

    this.dropdownSettings = {
      singleSelection: false,
      text: 'Select Date',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class',
      maxwidth: 100,
    };
  }

  getCustomers() {
    this.api.get(`${environment.backendDomain}ims/ticketsystem/getCustomers`).subscribe(res => {
      if (res.length > 0) {
        this.customers = res;
        if (this.selectedCustomer == null || this.selectedCustomer === undefined) {
          this.selectedCustomer = this.customers[0];
        }
        this.query['customer'] = this.selectedCustomer;
        this.getStatisticsList(this.query);
      } else {
        this.customers = [];
      }
    }, error => {
    });
  }

  getSysyemList() {
    this.api
      .get(`${environment.backendDomain}ims/ticketsystem/${this.selectedCustomer}/systemNames`)
      .subscribe(
        res => {
          _.each(res, (system, index) => {
            this.systemList.push({ itemName: system, id: index });
          });
        },
        error => {}
      );
  }

  removeItem(index) {
    this.query.systemNames.splice(index, 1);
  }

  getStatisticsList(query) {
    this.api
      .post(`${environment.backendDomain}ims/statistics/getStatistics`, query)
      .subscribe(
        res => {
          this.statisticsList = [];
          this.statisticsList = res;
        },
        error => { }
      );
  }

  clear() {
    this.query = {
      systemNames: [],
      source: null,
      automationStartDate: '',
      automationEndDate: ''
    };
    this.filterData();
  }

  filterData() {
    const query = Object.assign({}, this.query);
    query.automationStartDate = query.automationStartDate
      ? query.automationStartDate.getTime()
      : null;
    if (query.automationStartDate) {
      query.automationEndDate = query.automationEndDate
        ? query.automationEndDate.getTime() + (86400000 - 1)
        : new Date().getTime();
    } else {
      query.automationEndDate = null;
    }
    query.systemNames = _.map(query.systemNames, system => system.itemName);
    query['customer'] = this.selectedCustomer;
    this.getStatisticsList(query);
  }

  updateSysyemNames(event) { }

  onItemSelect(item: any) { }
  OnItemDeSelect(item: any) {
    console.log(item);
  }
  onSelectAll(items: any) { }
  onDeSelectAll(items: any) {
    console.log(items);
  }

  customerChange(value) {
    this.selectedCustomer = value;
    this.userService.setSelectedCustomer(this.selectedCustomer);
    const query = Object.assign({}, this.query);
    query['customer'] = this.selectedCustomer;
    this.getStatisticsList(query);
  }
}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, OnInit } from '@angular/core';
import { ValueComponent } from './value.component';

describe('ValueComponent', () => {
  let app: any;
  let fixture: ComponentFixture<ValueComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ValueComponent]
    }).compileComponents();
    fixture = TestBed.createComponent(ValueComponent);
    app = fixture.debugElement.componentInstance;
  }));

  it('should create', () => {
    expect(app).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Message } from '../../../models';
import { SocketService } from '../../../services/socket.service';
import { UserService } from '../../../services/user.service';
import { MessageService } from '../../../services/message.service';
import { AuthenticationService } from '../../../services/authentication.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SigninComponent } from './signin.component';
import { RouterTestingModule } from '@angular/router/testing';
import { FormsModule } from '@angular/forms';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';

describe(' SigninComponent', () => {
  let fixture: ComponentFixture<SigninComponent>;
  let app: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [SigninComponent],
      imports: [HttpClientTestingModule, RouterTestingModule, FormsModule],
      providers: [
        { provide: SocketService, useClass: SocketService },
        { provide: UserService, useClass: UserService },
        { provide: MessageService, useClass: MessageService },
        { provide: AuthenticationService, useClass: AuthenticationService }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(SigninComponent);
    app = fixture.debugElement.componentInstance;
  }));
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));

  it('should have ngOnInit', async(() => {
    expect(app.ngOnInit).toBeDefined();
    app.ngOnInit();
  }));

  it('should have login', async(() => {
    expect(app.login).toBeDefined();
    app._authenticationService.authenticationThroughChatbot = true;
    app.login();
  }));
});

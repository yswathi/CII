export interface IMessage {
  id?: string;
  type: string;
  text: string;
  sentAt: Date;
  from: string;
  idToken: string;
}
export class Message {
  id: string;
  type: string;
  text: string;
  sentAt: Date;
  from: string;
  idToken: string;

  constructor(obj?: IMessage) {
    this.id = obj && obj.id || null;
    this.type = obj && obj.type || null;
    this.text = obj && obj.text || null;
    this.sentAt = obj && obj.sentAt || new Date();
    this.from = obj && obj.from || 'admin';
    this.idToken = obj && obj.idToken || null;
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';
import { environment } from '../../environments/environment';

@Injectable()
export class AuthenticationService {
  public authenticationThroughChatbot = false;
  public idToken = '';

  constructor(private http: HttpClient) {}

  login(username: string, password: string) {
    return this.http
      .post<any>(environment.pythonDomain + 'login', {
        username: username,
        password: password
      })
      .toPromise()
      .then(response => response);
  }

  logout() {}
}

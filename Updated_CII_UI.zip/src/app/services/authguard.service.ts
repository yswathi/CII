import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRoute,Event,NavigationEnd,ActivatedRouteSnapshot } from '@angular/router';
import { Router } from '@angular/router';
// import { AngularFireAuth } from 'angularfire2/auth';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { ProxyService } from '../services/proxy.service';

@Injectable()
export class AuthGuard implements CanActivate {
  constructor(private router: Router, private http: HttpClient, private api: ProxyService, private route: ActivatedRoute) {}
  canActivate(rout: ActivatedRouteSnapshot) {
    return this.api.get(environment.backendDomain + 'ims/user').map(response => {
      const res = response;
      if (res.roles.length == 0 || res.resources.length === 0 || res.groups.length === 0)  {
        // Consume data here
        this.router.navigateByUrl('/AccessDenied')
        return false;
      }
      
      return true;
    });
  }
}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/switchMap';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'application/json'
    })
};

@Injectable()
export class ProxyService {
    url :String =  '';
    payload: any = {};
    constructor(
        private http: HttpClient) {
    }
    get(url,headerFlag?): Observable<any> {
        return headerFlag ? this.http.get(url, { headers: httpOptions.headers, responseType: 'text' } ) : this.http.get<any>(url);
    }
    patch(url): Observable<any> {
        return this.http.patch(url,{});
    }
    post(url, data: any): Observable<any> {
        return this.http.post<any>(url, data);
    }
    delete(url): Observable<{}> {
        return this.http.delete(url, { headers: httpOptions.headers, responseType: 'text' });
    }
    update(url, data: any): Observable<any> {
        return this.http.put<any>(url, data);
    }
    postdata(url,data:any){
        return this.http.post(url, data,{ observe: 'response',responseType:'arraybuffer'});
    }
    search(terms: Observable<any>) {
        return terms.debounceTime(400)
          .distinctUntilChanged()
          .switchMap(term => this.searchEntries(term));
    }
    
    searchEntries(term) {
        return this.post(this.url, this.payload);
    }
}

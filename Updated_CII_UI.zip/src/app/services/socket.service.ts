import { Injectable } from '@angular/core';
import * as io from 'socket.io-client';
import { MessageService } from './message.service';
import { UserService } from './user.service';
import { AuthenticationService } from './authentication.service';
import { Message, User } from '../models';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../environments/environment';

@Injectable()
export class SocketService {
  private socket;
  private searchDone: boolean;
  private searchIdentifier: number;
  private searchText: string;

  private isLoggedIn: Subject<boolean>;
  myLogging$: Observable<boolean>;

  constructor(
    private _userService: UserService,
    private _authenticationService: AuthenticationService,
    private _messageService: MessageService
  ) {
    this.isLoggedIn = new Subject<boolean>();
    this.myLogging$ = this.isLoggedIn.asObservable();
  }

  public connect() {
    // this.socket = io(environment.pythonDomain);
    /** For dev Build */
     this.socket = io('/',{ path :':3012'+environment.pythonDomain+'socket.io'});
    //  For uat Build
    // this.socket = io('/',{ path :':3022'+environment.pythonDomain+'socket.io'});
    // For prod Build
    // this.socket = io('/',{ path :':3000'+environment.pythonDomain+'socket.io'});
    this.socket.on('message', data => {
      if (data.eof === 'Y') {
        this.searchDone = false;
        this.searchIdentifier = null;
        this.searchText = null;
      }
      if (this.searchDone && data.searchtext && data.searchtext.length > 0) {
        this.searchIdentifier = data.id;
        this.searchText = data.searchtext;
      }
      this._authenticationService.idToken = data.idToken;
      if (data.type === 'request-feedback') {
        // This is a hack to show the feedback component in full width mode
        data.from = '';
      }
      this._messageService.addMessage(data);
      if (this._authenticationService.idToken) {
        this.isLoggedIn.next(true);
      } else {
        this.isLoggedIn.next(false);
      }
    });
  }

  public emit(message, actionType) {
    const modifiedMessage = Object.assign({}, message);
    modifiedMessage.idToken = this._authenticationService.idToken;
    if (this.searchDone) {
      if (this.searchText && this.searchText.length > 0) {
        modifiedMessage.is_first_time = 'N';
        modifiedMessage.idToken = null;
        modifiedMessage.searchtext =
          (this.searchText || '') + ' ' + modifiedMessage.text;
        modifiedMessage.text = 'Search';
      } else {
        modifiedMessage.searchtext = modifiedMessage.text;
        modifiedMessage.text = 'Search';
        modifiedMessage.is_first_time = 'Y';
      }
    }
    if (modifiedMessage.id === 5) {
      this.searchDone = true;
    }
    this.socket.emit(actionType, Object.assign({}, modifiedMessage));
  }

  public emitNAdd(message, actionType) {
    this.emit(message, actionType);
    this._messageService.addMessage(message);
  }
}

import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRoute,Event,NavigationEnd,ActivatedRouteSnapshot } from '@angular/router';
import { Router } from '@angular/router';
// import { AngularFireAuth } from 'angularfire2/auth';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { ProxyService } from '../services/proxy.service';

@Injectable()
export class SpecificRolesGuard implements CanActivate {
  constructor(private router: Router, private http: HttpClient, private api: ProxyService) {}
  canActivate(rout: ActivatedRouteSnapshot) {
    return this.api.get(environment.backendDomain + 'ims/user').map(response => {
      const res = response;
      const test =rout.data;
      res.resources.push('TAB0');
      if(res.resources.indexOf(test.rowMapper) == -1){
        this.router.navigateByUrl('/AccessDenied');
        return false;
      }
     
      
      return true;
    });
  }
}

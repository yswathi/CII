import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';
import { ProxyService } from '../app/services/proxy.service';
import { RequestOptions,Headers } from "@angular/http";
import { HttpClient, HttpHeaders } from '@angular/common/http';
declare var tableauSoftware: any;
import { MatSnackBar,MatCheckboxModule } from '@angular/material';

const httpOptions = {
    headers: new HttpHeaders({
        'Content-Type': 'multipart/form-data'
    })
};

@Injectable()
export class TableauService {

    constructor(private api: ProxyService, private http: HttpClient,  private snackBar: MatSnackBar){}

    setTableauViz(element: any, urlString: string) {
        this.api.get(environment.backendDomain + 'ims/user').subscribe((response) => {
            let form: FormData = new FormData();
            form.append('username', response.firstName);
            let headers : Headers = new Headers({'Content-Type': 'multipart/form-data'});
          
            let tableauTicketUrl = `${environment.tableauDomain}trusted`;
            this.http.post(tableauTicketUrl, form, { headers: httpOptions.headers, responseType: 'text' }).subscribe((res)=>{
                if(typeof res === 'string') {
                    const ticket = res;
                    if(ticket === '-1') {
                        this.snackBar.open('Invalid User or Token Expired, Please Contact Admin', 'Operation', { duration: 10000 });
                    }
                    var url = `${environment.tableauDomain}trusted/${ticket}/${urlString}`;
                    var options = {
                        width: '1350px',
                        height: '750px',
                        hideTabs: true,
                        hideToolbar: true,
                      };
                      new tableauSoftware.Viz(element, url, options);
                }
                
            }, (error) =>{
                console.log(error);
                // if(error.error.text){
                //     const ticket = error.error.text;
                //     if(ticket === '-1') {
                //         this.snackBar.open('Invalid User or Token Expired, Please Contact Admin', 'Operation', { duration: 10000 });
                //     }
                //     var url = `${environment.tableauDomain}trusted/${ticket}/${urlString}`;
                //     var options = {
                //         width: '1350px',
                //         height: '750px',
                //         hideTabs: true,
                //         hideToolbar: true,
                //       };
                //       new tableauSoftware.Viz(element, url, options);
                // }
            });
        });
    }
}
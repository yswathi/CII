import { Injectable } from '@angular/core';
import {
    HttpRequest,
    HttpHandler,
    HttpEvent,
    HttpInterceptor,
    HttpErrorResponse,
    HttpResponse,
} from '@angular/common/http';
import { KeycloakService } from './keyCloak.service';
import { Observable } from 'rxjs';
import { fromPromise } from 'rxjs/observable/fromPromise';

@Injectable()
export class TokenInterceptor implements HttpInterceptor {

    constructor(private kcService: KeycloakService) { }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return Observable.fromPromise(this.kcService.refreshToken())
        .switchMap((token) => {
            request = request.clone({
                setHeaders: {
                    Authorization: 'Bearer ' + token,
                },
            });
            return next.handle(request).do((event: HttpEvent<any>) => {
                    if (event instanceof HttpResponse) {
                    // process successful responses here
                    }
                    }, (error: any) => {
                    if (error instanceof HttpErrorResponse) {
                    if (error.status === 401) {
                        this.kcService.logout();
                    }
                    }
                    });
        });
            // const authToken = this.kcService.getToken();
            // request = request.clone({
            //     setHeaders: {
            //         Authorization: 'Bearer ' + authToken,
            //     },
            // });
            // return next.handle(request).do((event: HttpEvent<any>) => {
            //     if (event instanceof HttpResponse) {
            //     // process successful responses here
            //     }
            //     }, (error: any) => {
            //     if (error instanceof HttpErrorResponse) {
            //     if (error.status === 401) {
            //         this.kcService.logout();
            //     }
            //     }
            //     });
    }

}
